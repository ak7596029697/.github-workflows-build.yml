plugins {
    id("com.android.application")
}

android { namespace = "com.korx.orderscankeyboard"; compileSdk = 36
    defaultConfig { applicationId = "com.korx.orderscankeyboard"; minSdk = 23; targetSdk = 36; versionCode = 2; versionName = "1.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.camera:camera-camera2:1.6.2")
    implementation("androidx.camera:camera-lifecycle:1.6.2")
    implementation("androidx.camera:camera-view:1.6.2")
    implementation("com.google.android.gms:play-services-mlkit-text-recognition:19.0.1")
}
