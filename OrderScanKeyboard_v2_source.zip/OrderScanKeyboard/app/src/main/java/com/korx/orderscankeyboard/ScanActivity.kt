package com.korx.orderscankeyboard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.regex.Pattern

class ScanActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var resultText: TextView
    private lateinit var useButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val accepted = AtomicBoolean(false)
    private var candidate = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)
        preview = findViewById(R.id.preview)
        resultText = findViewById(R.id.resultText)
        useButton = findViewById(R.id.useButton)
        useButton.setOnClickListener { finishWith(candidate) }
        findViewById<Button>(R.id.cancelButton).setOnClickListener { finish() }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera() else finish()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            var lastTime = 0L
            analysis.setAnalyzer(executor) { proxy ->
                val now = System.currentTimeMillis()
                if (now - lastTime < 300) { proxy.close(); return@setAnalyzer }
                lastTime = now
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                recognizer.process(image).addOnSuccessListener { text ->
                    val found = extractOrderNumber(text.text)
                    if (found != null && !accepted.get()) runOnUiThread { showCandidate(found) }
                }.addOnCompleteListener { proxy.close() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showCandidate(value: String) {
        candidate = value
        resultText.text = "Order Number:\n$value"
        useButton.isEnabled = true
    }

    private fun finishWith(value: String) {
        if (value.isBlank()) return
        accepted.set(true)
        sendBroadcast(Intent(OrderInputMethodService.ACTION_ORDER_RESULT).setPackage(packageName).putExtra(OrderInputMethodService.EXTRA_ORDER, value))
        finish()
    }

    private fun extractOrderNumber(raw: String): String? {
        val normalized = raw.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        val amazon = Pattern.compile("\\b\\d{3}-\\d{7}-\\d{7}\\b").matcher(normalized)
        if (amazon.find()) return amazon.group()
        val flip = Pattern.compile("\\bOD[A-Z0-9]{8,}\\b", Pattern.CASE_INSENSITIVE).matcher(normalized)
        if (flip.find()) return flip.group().uppercase()
        // Explicitly labelled Order ID / Order No. This handles Meesho-style
        // plain numeric IDs with no OD prefix or hyphens.
        val labeled = Pattern.compile(
            "(?i)(?:order\\s*(?:id|no|number)|order\\s*#)\\s*[:#-]?\\s*([A-Z0-9][A-Z0-9-]{5,})"
        ).matcher(normalized)
        if (labeled.find()) return labeled.group(1).uppercase()

        // Plain numeric Order IDs (e.g. Meesho). Require 8+ digits to reduce
        // false matches from prices, PINs and quantities.
        val numericCandidates = Regex("\\b\\d{8,18}\\b").findAll(normalized).map { it.value }.toList()
        if (numericCandidates.size == 1) return numericCandidates[0]
        if (numericCandidates.isNotEmpty() && normalized.contains("meesho", ignoreCase = true)) {
            return numericCandidates.maxByOrNull { it.length }
        }
        return null
    }

    override fun onDestroy() {
        executor.shutdown()
        recognizer.close()
        super.onDestroy()
    }
}
