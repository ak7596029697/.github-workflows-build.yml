package com.korx.orderscankeyboard

import android.content.*
import android.inputmethodservice.InputMethodService
import android.view.*
import android.widget.Button

class OrderInputMethodService : InputMethodService() {
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_ORDER_RESULT) {
                val value = intent.getStringExtra(EXTRA_ORDER).orEmpty()
                if (value.isNotBlank()) currentInputConnection?.commitText(value, 1)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerReceiver(receiver, IntentFilter(ACTION_ORDER_RESULT), RECEIVER_NOT_EXPORTED)
    }

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.ime, null)
        view.findViewById<Button>(R.id.scanButton).setOnClickListener {
            val i = Intent(this, ScanActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        return view
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    companion object {
        const val ACTION_ORDER_RESULT = "com.korx.orderscankeyboard.ORDER_RESULT"
        const val EXTRA_ORDER = "order"
    }
}
